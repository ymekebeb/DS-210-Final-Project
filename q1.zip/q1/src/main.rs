use linfa::prelude::*;
use linfa_linear::{LinearRegression, FittedLinearRegression};
use ndarray::{Array1, Array2};
use csv::Reader;
use std::error::Error;

/// enum stands for if the they would pass or fail the bar exam
#[derive(Debug, PartialEq, Clone)]
enum BarOutcome {
    Pass,
    Fail,
}

/// struct has the data of the students 
#[derive(Debug)]
struct Student {
    id: u32,
    gpa: f32,
    lsat_score: u32,
    study_hours: u32,
    bar_outcome: Option<BarOutcome>,
    performance_tier: Option<String>,
}

/// function that allows me to load student info
fn load_students_from_csv(file_path: &str) -> Result<Vec<Student>, Box<dyn Error>> {
    let mut students = Vec::new();
    let mut reader = Reader::from_path(file_path)?;
    for result in reader.records() {
        let record = result?;
        students.push(parse_student_record(&record));
    }
    Ok(students)
}

/// this function parses the csv into the struct 
fn parse_student_record(record: &csv::StringRecord) -> Student {
    Student {
        id: record[0].parse().unwrap_or_default(),
        gpa: record[1].parse().unwrap_or_default(),
        lsat_score: record[2].parse().unwrap_or_default(),
        study_hours: record[3].parse().unwrap_or_default(),
        bar_outcome: None,
        performance_tier: None,
    }
}

/// preparing the data to do the regression 
fn prepare_data(students: &[Student]) -> (Array2<f32>, Array1<f32>) {
    let features = extract_features(students);
    let targets = extract_targets(students);
    (
        Array2::from_shape_vec((students.len(), 3), features).unwrap(),
        Array1::from(targets),
    )
}

/// extracting gpa, lsat, study hours info of the students
fn extract_features(students: &[Student]) -> Vec<f32> {
    students
        .iter()
        .flat_map(|s| vec![s.gpa, s.lsat_score as f32, s.study_hours as f32])
        .collect()
}

/// extract the outcomes
fn extract_targets(students: &[Student]) -> Vec<f32> {
    students
        .iter()
        .map(|s| if matches!(s.bar_outcome, Some(BarOutcome::Pass)) { 1.0 } else { 0.0 })
        .collect()
}

/// scaling the features
fn scale_features(features: Array2<f32>) -> Array2<f32> {
    let mut scaled = features.clone();
    for mut col in scaled.columns_mut() {
        scale_column(&mut col);
    }
    scaled
}

/// scaling the column
fn scale_column(column: &mut ndarray::ArrayViewMut1<f32>) {
    let max = column.fold(f32::MIN, |a, &b| a.max(b));
    let min = column.fold(f32::MAX, |a, &b| a.min(b));
    for val in column {
        *val = (*val - min) / (max - min + 1e-8); 
    }
}

/// training the mondel for the linear regression
fn train_model(features: Array2<f32>, targets: Array1<f32>) -> FittedLinearRegression<f32> {
    let dataset = create_dataset(features, targets);
    let model = LinearRegression::default();
    model.fit(&dataset).unwrap()
}

/// function helps me creat the dataset with all the info needed
fn create_dataset(features: Array2<f32>, targets: Array1<f32>) -> DatasetBase<Array2<f32>, Array1<f32>> {
    DatasetBase::from((features, targets))
}

/// predicts bar for students
fn predict_with_model(model: &FittedLinearRegression<f32>, students: &mut Vec<Student>, features: Array2<f32>) {
    let predictions = model.predict(&features);
    apply_predictions_to_students(students, &predictions);
}

/// this function applies predictions to the info in the struct
fn apply_predictions_to_students(students: &mut Vec<Student>, predictions: &Array1<f32>) {
    for (student, &prediction) in students.iter_mut().zip(predictions.iter()) {
        student.bar_outcome = Some(determine_outcome(prediction));
    }
}

/// determines if they will pass or fail
fn determine_outcome(prediction: f32) -> BarOutcome {
    if prediction >= 0.5 {
        BarOutcome::Pass
    } else {
        BarOutcome::Fail
    }
}

/// assigns the student performance 
fn assign_performance_tier(student: &mut Student) {
    student.performance_tier = Some(determine_performance_tier(student.gpa));
}

/// student performance is determined by the GPA
fn determine_performance_tier(gpa: f32) -> String {
    if gpa > 3.5 {
        "Top Tier".to_string()
    } else if gpa > 3.0 {
        "Middle Tier".to_string()
    } else {
        "Lower Tier".to_string()
    }
}

fn log_student_data(students: &[Student]) {
    println!("\nDetailed Student Records:");
    for student in students {
        log_student_record(student);
    }
}

/// logging the student information 
fn log_student_record(student: &Student) {
    println!(
        "ID: {}, GPA: {:.2}, LSAT: {}, Hours: {}, Outcome: {:?}, Tier: {}",
        student.id,
        student.gpa,
        student.lsat_score,
        student.study_hours,
        student.bar_outcome,
        student.performance_tier.as_deref().unwrap_or("Unknown")
    );
}

/// main function
fn main() -> Result<(), Box<dyn Error>> {
    let file_path = "bar_pass_prediction.csv";

    let mut students = load_students_from_csv(file_path)?;

    let (mut features, targets) = prepare_data(&students);
    features = scale_features(features);

    let model = train_model(features.clone(), targets);

    predict_with_model(&model, &mut students, features);

    for student in &mut students {
        assign_performance_tier(student);
    }

    log_student_data(&students);

    Ok(())
}

//tests
#[cfg(test)]
mod tests {
    use super::*;
    use ndarray::{array, Array2};

    #[test]
    fn test_parse_student_record() {
        let record = csv::StringRecord::from(vec!["1", "3.8", "160", "20"]);
        let student = parse_student_record(&record);
        assert_eq!(student.id, 1);
        assert_eq!(student.gpa, 3.8);
        assert_eq!(student.lsat_score, 160);
        assert_eq!(student.study_hours, 20);
        assert!(student.bar_outcome.is_none());
        assert!(student.performance_tier.is_none());
    }

    #[test]
    fn test_extract_features() {
        let students = vec![
            Student {
                id: 1,
                gpa: 3.5,
                lsat_score: 160,
                study_hours: 15,
                bar_outcome: None,
                performance_tier: None,
            },
            Student {
                id: 2,
                gpa: 3.0,
                lsat_score: 155,
                study_hours: 20,
                bar_outcome: None,
                performance_tier: None,
            },
        ];
        let features = extract_features(&students);
        assert_eq!(features, vec![3.5, 160.0, 15.0, 3.0, 155.0, 20.0]);
    }

    #[test]
    fn test_extract_targets() {
        let students = vec![
            Student {
                id: 1,
                gpa: 3.5,
                lsat_score: 160,
                study_hours: 15,
                bar_outcome: Some(BarOutcome::Pass),
                performance_tier: None,
            },
            Student {
                id: 2,
                gpa: 3.0,
                lsat_score: 155,
                study_hours: 20,
                bar_outcome: Some(BarOutcome::Fail),
                performance_tier: None,
            },
        ];
        let targets = extract_targets(&students);
        assert_eq!(targets, vec![1.0, 0.0]);
    }

    #[test]
    fn test_scale_column() {
        let mut column = array![10.0, 20.0, 30.0];
        scale_column(&mut column.view_mut());
        assert_eq!(column, array![0.0, 0.5, 1.0]);
    }

    #[test]
    fn test_scale_features() {
        let features = array![[10.0, 20.0], [30.0, 40.0]];
        let scaled = scale_features(features);
        assert_eq!(scaled, array![[0.0, 0.0], [1.0, 1.0]]);
    }

    #[test]
    fn test_determine_outcome() {
        assert_eq!(determine_outcome(0.7), BarOutcome::Pass);
        assert_eq!(determine_outcome(0.3), BarOutcome::Fail);
    }

    #[test]
    fn test_assign_performance_tier() {
        let mut student = Student {
            id: 1,
            gpa: 3.7,
            lsat_score: 160,
            study_hours: 15,
            bar_outcome: None,
            performance_tier: None,
        };
        assign_performance_tier(&mut student);
        assert_eq!(student.performance_tier.as_deref(), Some("Top Tier"));
    }

    #[test]
    fn test_log_student_record() {
        let student = Student {
            id: 1,
            gpa: 3.7,
            lsat_score: 160,
            study_hours: 15,
            bar_outcome: Some(BarOutcome::Pass),
            performance_tier: Some("Top Tier".to_string()),
        };
        log_student_record(&student); // This test will print to the console
    }

    #[test]
    fn test_create_dataset() {
        let features = array![[1.0, 2.0], [3.0, 4.0]];
        let targets = array![1.0, 0.0];
        let dataset = create_dataset(features.clone(), targets.clone());
        assert_eq!(dataset.records(), &features);
        assert_eq!(dataset.targets(), &targets);
    }

    #[test]
    fn test_predict_with_model() {
        let mut students = vec![
            Student {
                id: 1,
                gpa: 3.5,
                lsat_score: 160,
                study_hours: 15,
                bar_outcome: None,
                performance_tier: None,
            },
            Student {
                id: 2,
                gpa: 3.0,
                lsat_score: 155,
                study_hours: 20,
                bar_outcome: None,
                performance_tier: None,
            },
        ];

        let features = array![[1.0, 2.0, 3.0], [4.0, 5.0, 6.0]];
        let targets = array![1.0, 0.0];
        let model = train_model(features.clone(), targets);

        predict_with_model(&model, &mut students, features);

        assert_eq!(students[0].bar_outcome, Some(BarOutcome::Pass));
        assert_eq!(students[1].bar_outcome, Some(BarOutcome::Fail));
    }
}
